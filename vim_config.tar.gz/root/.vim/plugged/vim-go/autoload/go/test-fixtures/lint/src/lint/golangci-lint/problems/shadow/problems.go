package problems

func mySleep(time int) {
	time.Sleep(500 * time.Millisecond)
}
